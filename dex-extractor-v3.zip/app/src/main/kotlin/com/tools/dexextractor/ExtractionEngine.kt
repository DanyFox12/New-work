package com.tools.dexextractor

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class ExtractionEngine(private val context: Context) {

    data class ExtractionResult(
        val success: Boolean,
        val outputDir: File?,
        val dexCount: Int,
        val reportPath: String?,
        val log: List<String>
    )

    suspend fun extract(packageName: String): ExtractionResult =
        withContext(Dispatchers.IO) {
            val log = mutableListOf<String>()
            val allDex = mutableListOf<ByteArray>()
            val seenHashes = mutableSetOf<String>()
            val strategiesUsed = mutableListOf<String>()

            log.add("══════════════════════════════════")
            log.add("  DEX Extractor v3.0")
            log.add("  Package: $packageName")
            log.add("══════════════════════════════════")

            // Init root
            RootShell.init()
            if (!RootShell.isAvailable()) {
                log.add("❌ Root not available — cannot continue")
                return@withContext ExtractionResult(false, null, 0, null, log)
            }
            log.add("✓ Root access confirmed")

            // Detect packer
            log.add("")
            log.add("--- Packer Detection ---")
            val apkPath = findApkPath(packageName, log)
            var packerInfo = "unknown"

            if (apkPath != null) {
                val detection = PackerDetector.detect(apkPath)
                packerInfo = detection.type.displayName
                log.add("Packer: ${detection.type.displayName} [${detection.confidence}]")
                detection.evidence.forEach { log.add("  Evidence: $it") }
            }

            // ── Strategy 1: Filesystem scan ──────────────────────
            log.add("")
            log.add("--- Strategy 1: Filesystem Scan ---")
            val fsResult = FilesystemScanner(context).scan(packageName)
            log.addAll(fsResult.log)
            fsResult.dexList.forEach { bytes ->
                val hash = DexVerifier.sha256(bytes)
                if (seenHashes.add(hash)) allDex.add(bytes)
            }
            if (fsResult.dexList.isNotEmpty()) strategiesUsed.add("filesystem")
            log.add("Strategy 1 result: ${fsResult.dexList.size} DEX found")

            // ── Strategy 2: Launch app + scan its process memory ─
            log.add("")
            log.add("--- Strategy 2: Process Memory Scan ---")

            // Stop app first (clean state)
            RootShell.stopApp(packageName)
            Thread.sleep(500)

            // Launch app
            log.add("Launching $packageName...")
            val launched = RootShell.startApp(packageName)
            if (!launched) {
                log.add("⚠ Could not launch app via monkey — trying am start")
                RootShell.exec("am start -n $packageName 2>/dev/null")
            }

            // Wait for app to unpack (give packer time to decrypt)
            val waitTime = when {
                packerInfo.contains("dpt") -> 4000L
                packerInfo.contains("360") -> 5000L
                packerInfo.contains("Tencent") -> 5000L
                else -> 4000L
            }
            log.add("Waiting ${waitTime/1000}s for packer to decrypt...")
            Thread.sleep(waitTime)

            // Get PID
            val pid = RootShell.getPid(packageName)
            if (pid == null) {
                log.add("⚠ Cannot find PID for $packageName")
            } else {
                log.add("Found PID: $pid — scanning memory...")
                val memResult = ProcessMemoryScanner().scan(pid)
                log.addAll(memResult.log)
                memResult.dexList.forEach { bytes ->
                    val hash = DexVerifier.sha256(bytes)
                    if (seenHashes.add(hash)) allDex.add(bytes)
                }
                if (memResult.dexList.isNotEmpty()) strategiesUsed.add("process-memory")
                log.add("Strategy 2 result: ${memResult.dexList.size} DEX found")
            }

            // Stop app after scan
            RootShell.stopApp(packageName)
            log.add("App stopped")

            // ── Strategy 3: Re-scan filesystem after app ran ─────
            log.add("")
            log.add("--- Strategy 3: Post-run Filesystem Scan ---")
            val fsResult2 = FilesystemScanner(context).scan(packageName)
            log.addAll(fsResult2.log)
            fsResult2.dexList.forEach { bytes ->
                val hash = DexVerifier.sha256(bytes)
                if (seenHashes.add(hash)) {
                    allDex.add(bytes)
                    log.add("New DEX found after app run!")
                }
            }
            if (fsResult2.dexList.isNotEmpty()) strategiesUsed.add("post-run-filesystem")

            // ── Filter results ───────────────────────────────────
            // Remove stub DEX (< 50KB) and known loader classes
            val realDex = allDex.filter { bytes ->
                if (bytes.size < 50 * 1024) return@filter false
                // Filter out stub signatures
                val sample = String(
                    bytes.copyOfRange(0, minOf(bytes.size, 4096)),
                    Charsets.ISO_8859_1
                )
                val isStub = sample.contains("ProxyApplication") &&
                             sample.contains("JniBridge") &&
                             bytes.size < 200 * 1024
                !isStub
            }

            val filteredCount = allDex.size - realDex.size
            if (filteredCount > 0) {
                log.add("Filtered $filteredCount stub/small DEX file(s)")
            }

            // ── Save results ─────────────────────────────────────
            log.add("")
            log.add("══════════════════════════════════")
            log.add("Total unique DEX: ${realDex.size}")

            if (realDex.isEmpty()) {
                log.add("⚠ No real DEX files extracted")
                log.add("Tips:")
                log.add("  - Make sure app is installed")
                log.add("  - Try extracting again (packer may need more time)")
                log.add("  - Some apps require user interaction to unpack")
                return@withContext ExtractionResult(false, null, 0, null, log)
            }

            // Create output directory
            val timestamp = System.currentTimeMillis() / 1000
            val outDir = File("/sdcard/dex_output/$packageName/$timestamp")
            outDir.mkdirs()

            if (!outDir.exists()) {
                // Fallback to app storage
                val fallback = File(context.getExternalFilesDir(null),
                    "dex_output/$packageName/$timestamp")
                fallback.mkdirs()
            }

            val savedFiles = mutableListOf<Pair<File, ByteArray>>()
            realDex.forEachIndexed { i, bytes ->
                val outFile = File(outDir, "dump_${i}_${bytes.size}.dex")
                try {
                    outFile.writeBytes(bytes)
                    savedFiles.add(Pair(outFile, bytes))
                    log.add("✅ dump_${i}_${bytes.size}.dex")
                } catch (e: Exception) {
                    log.add("❌ Save failed: ${e.message}")
                }
            }

            // Write report
            val reportFile = try {
                ReportWriter.write(outDir, packageName, savedFiles,
                    strategiesUsed, packerInfo)
            } catch (_: Exception) { null }

            reportFile?.let { log.add("📄 report.json saved") }
            log.add("📁 Output: ${outDir.absolutePath}")
            log.add("══════════════════════════════════")

            ExtractionResult(
                success     = savedFiles.isNotEmpty(),
                outputDir   = outDir,
                dexCount    = savedFiles.size,
                reportPath  = reportFile?.absolutePath,
                log         = log
            )
        }

    private fun findApkPath(packageName: String, log: MutableList<String>): String? {
        try {
            val info = context.packageManager.getApplicationInfo(packageName, 0)
            if (info.sourceDir != null) return info.sourceDir
        } catch (_: Exception) {}

        val pm = RootShell.exec("pm path $packageName 2>/dev/null")
        if (pm.contains("package:")) {
            return pm.substringAfter("package:").trim()
        }
        return null
    }
}
