package com.tools.dexextractor

import com.google.gson.GsonBuilder
import java.io.File

object ReportWriter {

    data class DexEntry(
        val index: Int,
        val filename: String,
        val path: String,
        val size_bytes: Int,
        val size_kb: String,
        val sha256: String,
        val dex_version: String
    )

    data class Report(
        val package_name: String,
        val timestamp: Long,
        val packer: String,
        val strategies_used: List<String>,
        val total_dex_found: Int,
        val output_dir: String,
        val dex_files: List<DexEntry>
    )

    fun write(
        outputDir: File,
        packageName: String,
        dexFiles: List<Pair<File, ByteArray>>,
        strategiesUsed: List<String>,
        packerInfo: String = "unknown"
    ): File {
        val entries = dexFiles.mapIndexed { i, (file, bytes) ->
            val info = DexVerifier.getInfo(bytes)
            DexEntry(
                index      = i,
                filename   = file.name,
                path       = file.absolutePath,
                size_bytes = bytes.size,
                size_kb    = "${bytes.size / 1024} KB",
                sha256     = info?.sha256 ?: DexVerifier.sha256(bytes),
                dex_version = info?.version ?: "unknown"
            )
        }
        val report = Report(
            package_name    = packageName,
            timestamp       = System.currentTimeMillis() / 1000,
            packer          = packerInfo,
            strategies_used = strategiesUsed,
            total_dex_found = dexFiles.size,
            output_dir      = outputDir.absolutePath,
            dex_files       = entries
        )
        val gson = GsonBuilder().setPrettyPrinting().create()
        val reportFile = File(outputDir, "report.json")
        reportFile.writeText(gson.toJson(report))
        return reportFile
    }
}
