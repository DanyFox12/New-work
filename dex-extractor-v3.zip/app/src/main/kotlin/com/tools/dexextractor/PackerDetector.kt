package com.tools.dexextractor

import java.util.zip.ZipFile

/**
 * Detects which packer/protector an APK uses.
 * Supports: dpt-shell, 360Jiagu, Bangcle, Qihoo, Tencent,
 *           Ijiami, Alibaba, Kiro, NagaGuard, and unknown.
 */
object PackerDetector {

    enum class PackerType(val displayName: String) {
        DPT_SHELL("dpt-shell"),
        JIAGU_360("360 Jiagu"),
        BANGCLE("Bangcle / SecShell"),
        TENCENT("Tencent Legu"),
        IJIAMI("Ijiami"),
        ALIBABA("Alibaba / Walle"),
        QIHOO("Qihoo 360"),
        NAGA("NagaGuard"),
        KIRO("Kiro"),
        UNKNOWN("Unknown / None")
    }

    data class DetectionResult(
        val type: PackerType,
        val confidence: String,   // HIGH / MEDIUM / LOW
        val evidence: List<String>
    )

    fun detect(apkPath: String): DetectionResult {
        val evidence = mutableListOf<String>()

        return try {
            ZipFile(apkPath).use { zip ->
                val entries = zip.entries().toList().map { it.name }

                // ── dpt-shell ────────────────────────────────────
                if (entries.any { it.contains("vwwwwwvwww") } ||
                    entries.any { it == "assets/vwwwwwvwww/" }) {
                    evidence.add("assets/vwwwwwvwww/ directory")
                    checkNativeLib(entries, "libdpt.so", evidence)
                    return DetectionResult(PackerType.DPT_SHELL, "HIGH", evidence)
                }

                // ── 360 Jiagu ────────────────────────────────────
                if (entries.any { it.contains("libjiagu") } ||
                    entries.any { it.contains("libprotectClass") }) {
                    evidence.add("libjiagu*.so found")
                    checkNativeLib(entries, "libjiagu", evidence)
                    return DetectionResult(PackerType.JIAGU_360, "HIGH", evidence)
                }

                // ── Bangcle / SecShell ───────────────────────────
                if (entries.any { it.contains("libsecexe") } ||
                    entries.any { it.contains("libSecShell") } ||
                    entries.any { it.contains("bangcle") }) {
                    evidence.add("Bangcle native libs found")
                    return DetectionResult(PackerType.BANGCLE, "HIGH", evidence)
                }

                // ── Tencent Legu ─────────────────────────────────
                if (entries.any { it.contains("libshell-super") } ||
                    entries.any { it.contains("libtup.so") } ||
                    entries.any { it.contains("libBugly") && it.contains("libshell") }) {
                    evidence.add("Tencent shell libs found")
                    return DetectionResult(PackerType.TENCENT, "HIGH", evidence)
                }

                // ── Ijiami ───────────────────────────────────────
                if (entries.any { it.contains("libexec.so") } ||
                    entries.any { it.contains("ijiami") }) {
                    evidence.add("Ijiami libs found")
                    return DetectionResult(PackerType.IJIAMI, "MEDIUM", evidence)
                }

                // ── NagaGuard ────────────────────────────────────
                if (entries.any { it.contains("libnaga") } ||
                    entries.any { it.contains("libNaga") }) {
                    evidence.add("NagaGuard libs found")
                    return DetectionResult(PackerType.NAGA, "HIGH", evidence)
                }

                // ── Check by stub classes in DEX ─────────────────
                val classesEntries = entries.filter {
                    it.matches(Regex("classes\\d*\\.dex"))
                }
                classesEntries.forEach { dexEntry ->
                    val bytes = try {
                        zip.getInputStream(zip.getEntry(dexEntry))
                            .readBytes()
                    } catch (_: Exception) { return@forEach }
                    val str = String(bytes, Charsets.ISO_8859_1)

                    when {
                        str.contains("com/luoyesiqiu/shell") -> {
                            evidence.add("dpt-shell stub class in $dexEntry")
                            return DetectionResult(PackerType.DPT_SHELL, "HIGH", evidence)
                        }
                        str.contains("com/qihoo/util") ||
                        str.contains("com/qihoo360") -> {
                            evidence.add("Qihoo stub in $dexEntry")
                            return DetectionResult(PackerType.QIHOO, "HIGH", evidence)
                        }
                        str.contains("com/secneo/apkwrapper") -> {
                            evidence.add("Bangcle stub in $dexEntry")
                            return DetectionResult(PackerType.BANGCLE, "HIGH", evidence)
                        }
                        str.contains("com/tencent/StubShell") -> {
                            evidence.add("Tencent stub in $dexEntry")
                            return DetectionResult(PackerType.TENCENT, "HIGH", evidence)
                        }
                    }
                }

                evidence.add("No known packer signatures found")
                DetectionResult(PackerType.UNKNOWN, "LOW", evidence)
            }
        } catch (e: Exception) {
            evidence.add("Detection error: ${e.message}")
            DetectionResult(PackerType.UNKNOWN, "LOW", evidence)
        }
    }

    private fun checkNativeLib(
        entries: List<String>,
        libName: String,
        evidence: MutableList<String>
    ) {
        entries.filter { it.contains(libName) }.forEach {
            evidence.add("Native lib: $it")
        }
    }
}
