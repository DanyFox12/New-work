package com.tools.dexextractor

import com.topjohnwu.superuser.Shell

object RootShell {

    fun init() {
        try {
            Shell.setDefaultBuilder(
                Shell.Builder.create()
                    .setFlags(Shell.FLAG_REDIRECT_STDERR)
                    .setTimeout(30)
            )
        } catch (e: IllegalStateException) {
            // Already created — ignore
        }
    }

    fun isAvailable(): Boolean {
        return try {
            Shell.getShell().isRoot
        } catch (e: Exception) { false }
    }

    fun exec(cmd: String): String {
        return try {
            Shell.cmd(cmd).exec().out.joinToString("\n")
        } catch (e: Exception) { "" }
    }

    fun execLines(cmd: String): List<String> {
        return try {
            Shell.cmd(cmd).exec().out.filter { it.isNotBlank() }
        } catch (e: Exception) { emptyList() }
    }

    fun execBool(cmd: String): Boolean {
        return try {
            Shell.cmd(cmd).exec().isSuccess
        } catch (e: Exception) { false }
    }

    fun copy(src: String, dst: String): Boolean {
        return execBool("cp -f '$src' '$dst' 2>/dev/null")
    }

    fun listDir(path: String): List<String> {
        return execLines("ls '$path' 2>/dev/null")
    }

    fun exists(path: String): Boolean {
        return exec("[ -e '$path' ] && echo 1 || echo 0").trim() == "1"
    }

    fun mkdir(path: String) {
        exec("mkdir -p '$path' 2>/dev/null")
    }

    fun chmod(path: String, mode: String = "777") {
        exec("chmod $mode '$path' 2>/dev/null")
    }

    fun readBytes(path: String): ByteArray? {
        return try {
            val tmp = "/data/local/tmp/_r${System.currentTimeMillis()}"
            exec("cp '$path' '$tmp' 2>/dev/null && chmod 777 '$tmp' 2>/dev/null")
            val f = java.io.File(tmp)
            if (f.exists() && f.length() > 0) {
                val b = f.readBytes()
                f.delete()
                b
            } else null
        } catch (e: Exception) { null }
    }

    fun getPid(packageName: String): String? {
        val out = exec("pidof $packageName 2>/dev/null").trim()
        if (out.isNotBlank()) return out.split(" ").firstOrNull()
        // Fallback via ps
        val ps = exec("ps -A 2>/dev/null | grep $packageName | grep -v grep")
        return ps.trim().split("\\s+".toRegex()).getOrNull(1)
    }

    fun startApp(packageName: String): Boolean {
        return execBool(
            "monkey -p $packageName -c android.intent.category.LAUNCHER 1 2>/dev/null"
        )
    }

    fun stopApp(packageName: String) {
        exec("am force-stop $packageName 2>/dev/null")
    }
}
