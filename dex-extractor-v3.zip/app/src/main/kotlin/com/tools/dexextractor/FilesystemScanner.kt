package com.tools.dexextractor

import java.io.File
import java.util.zip.ZipFile

/**
 * Scans target app filesystem paths for extracted DEX files.
 * Packers often write decrypted DEX to app's data directory.
 */
class FilesystemScanner(private val context: android.content.Context) {

    data class ScanResult(
        val dexList: List<ByteArray>,
        val log: List<String>
    )

    fun scan(packageName: String): ScanResult {
        val log = mutableListOf<String>()
        val found = mutableListOf<ByteArray>()
        val seenHashes = mutableSetOf<String>()

        log.add("[FS] Filesystem scan for: $packageName")

        // All possible locations where packers extract DEX
        val searchPaths = listOf(
            "/data/data/$packageName",
            "/data/data/$packageName/app_dex",
            "/data/data/$packageName/files",
            "/data/data/$packageName/cache",
            "/data/data/$packageName/code_cache",
            "/data/data/$packageName/app_dexopt",
            "/data/data/$packageName/files/dex",
            "/data/user/0/$packageName",
            "/data/user/0/$packageName/app_dex",
            "/data/user/0/$packageName/files",
            "/data/user/0/$packageName/cache",
            "/data/local/tmp",
        )

        // Find APK and scan it too
        val apkPath = findApkPath(packageName, log)
        if (apkPath != null) {
            extractFromApk(apkPath, log, found, seenHashes)
        }

        // Search all data paths recursively
        searchPaths.forEach { path ->
            if (RootShell.exists(path)) {
                log.add("[FS] Searching: $path")
                findDexInDir(path, log, found, seenHashes)
            }
        }

        log.add("[FS] Done — found ${found.size} DEX file(s)")
        return ScanResult(found, log)
    }

    private fun findApkPath(packageName: String, log: MutableList<String>): String? {
        // Via PackageManager
        try {
            val info = context.packageManager.getApplicationInfo(packageName, 0)
            if (info.sourceDir != null) {
                log.add("[FS] APK: ${info.sourceDir}")
                return info.sourceDir
            }
        } catch (_: Exception) {}

        // Via root pm
        val pm = RootShell.exec("pm path $packageName 2>/dev/null")
        if (pm.contains("package:")) {
            val path = pm.substringAfter("package:").trim()
            if (path.isNotEmpty()) {
                log.add("[FS] APK (root pm): $path")
                return path
            }
        }

        // Find in /data/app
        val find = RootShell.exec(
            "find /data/app -name 'base.apk' 2>/dev/null | grep $packageName | head -1"
        ).trim()
        if (find.isNotEmpty()) {
            log.add("[FS] APK (find): $find")
            return find
        }

        log.add("[FS] APK not found for $packageName")
        return null
    }

    private fun extractFromApk(
        apkPath: String,
        log: MutableList<String>,
        found: MutableList<ByteArray>,
        seenHashes: MutableSet<String>
    ) {
        val tmpApk = File(context.cacheDir, "scan_${System.currentTimeMillis()}.apk")
        try {
            if (!RootShell.copy(apkPath, tmpApk.absolutePath)) {
                log.add("[FS] Cannot copy APK")
                return
            }
            tmpApk.setReadable(true, false)

            ZipFile(tmpApk).use { zip ->
                val entries = zip.entries().toList()
                log.add("[FS] APK entries: ${entries.size}")

                entries.forEach { entry ->
                    val name = entry.name
                    try {
                        val bytes = zip.getInputStream(entry).readBytes()

                        // Standard DEX entries
                        if (name.matches(Regex("classes\\d*\\.dex")) &&
                            DexVerifier.isValid(bytes)) {
                            val hash = DexVerifier.sha256(bytes)
                            if (seenHashes.add(hash)) {
                                found.add(bytes)
                                log.add("[FS] APK DEX: $name (${bytes.size / 1024}KB)")
                            }
                            return@forEach
                        }

                        // Assets that might be encrypted DEX
                        // (some packers store DEX-like data in assets)
                        if (name.startsWith("assets/") && bytes.size >= 50 * 1024) {
                            if (DexVerifier.isValid(bytes)) {
                                val hash = DexVerifier.sha256(bytes)
                                if (seenHashes.add(hash)) {
                                    found.add(bytes)
                                    log.add("[FS] Asset DEX: $name (${bytes.size / 1024}KB)")
                                }
                            }
                        }
                    } catch (_: Exception) {}
                }
            }
        } catch (e: Exception) {
            log.add("[FS] APK scan error: ${e.message}")
        } finally {
            tmpApk.delete()
        }
    }

    private fun findDexInDir(
        dirPath: String,
        log: MutableList<String>,
        found: MutableList<ByteArray>,
        seenHashes: MutableSet<String>
    ) {
        // Find all .dex, .vdex, .jar, .odex files
        val files = RootShell.exec(
            "find '$dirPath' \\( -name '*.dex' -o -name '*.vdex' " +
            "-o -name '*.odex' -o -name '*.jar' \\) 2>/dev/null"
        ).lines().filter { it.isNotBlank() }

        if (files.isEmpty()) {
            log.add("[FS] $dirPath — no DEX files")
            return
        }

        log.add("[FS] $dirPath — ${files.size} candidate file(s)")

        files.forEach { filePath ->
            val bytes = RootShell.readBytes(filePath) ?: return@forEach
            if (DexVerifier.isValid(bytes)) {
                val hash = DexVerifier.sha256(bytes)
                if (seenHashes.add(hash)) {
                    found.add(bytes)
                    log.add("[FS] ✅ Found: $filePath (${bytes.size / 1024}KB)")
                }
            }
        }
    }
}
