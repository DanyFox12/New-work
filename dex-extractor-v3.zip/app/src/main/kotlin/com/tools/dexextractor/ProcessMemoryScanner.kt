package com.tools.dexextractor

import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Scans a TARGET process's memory via root access.
 * Reads /proc/<pid>/maps and /proc/<pid>/mem directly.
 * This works on the target app's process, not our own.
 */
class ProcessMemoryScanner {

    data class ScanResult(
        val dexList: List<ByteArray>,
        val log: List<String>
    )

    private val DEX_MAGIC = byteArrayOf(0x64, 0x65, 0x78, 0x0a) // "dex\n"
    private val CHUNK_SIZE = 16 * 1024 * 1024  // 16 MB per read chunk
    private val MIN_DEX_SIZE = 50 * 1024        // 50 KB minimum

    private val SYSTEM_PATHS = listOf(
        "/system/", "/apex/", "/vendor/", "/product/",
        "/data/dalvik-cache", "/dev/", "libc.so",
        "libandroid_runtime", "libdvm", "libfrida"
    )

    fun scan(pid: String): ScanResult {
        val log = mutableListOf<String>()
        val found = mutableListOf<ByteArray>()
        val seenHashes = mutableSetOf<String>()

        log.add("[MEM] Scanning process PID=$pid")

        // Read /proc/<pid>/maps via root
        val mapsContent = RootShell.exec("cat /proc/$pid/maps 2>/dev/null")
        if (mapsContent.isBlank()) {
            log.add("[MEM] Cannot read /proc/$pid/maps")
            return ScanResult(found, log)
        }

        val lines = mapsContent.lines().filter { it.isNotBlank() }
        log.add("[MEM] Found ${lines.size} memory regions")

        var scanned = 0
        var skipped = 0

        lines.forEach { line ->
            val region = parseMapLine(line) ?: run { skipped++; return@forEach }

            // Only readable regions
            if (!region.perms.contains('r')) { skipped++; return@forEach }

            // Skip write+execute (JIT code) — not DEX
            // Skip tiny regions
            val size = (region.end - region.start).toInt()
            if (size < MIN_DEX_SIZE) { skipped++; return@forEach }

            // Skip system libs
            if (region.pathname != null && isSystemPath(region.pathname)) {
                skipped++; return@forEach
            }

            scanned++
            val dexes = readAndScanRegion(pid, region.start, region.end, size, log)
            dexes.forEach { bytes ->
                val hash = DexVerifier.sha256(bytes)
                if (seenHashes.add(hash)) {
                    found.add(bytes)
                    log.add("[MEM] ✅ DEX @ 0x${region.start.toString(16)} " +
                            "size=${bytes.size} (${bytes.size / 1024}KB)")
                }
            }
        }

        log.add("[MEM] Scanned=$scanned skipped=$skipped found=${found.size}")
        return ScanResult(found, log)
    }

    private data class MapRegion(
        val start: Long,
        val end: Long,
        val perms: String,
        val pathname: String?
    )

    private fun parseMapLine(line: String): MapRegion? {
        return try {
            val parts = line.trim().split("\\s+".toRegex())
            if (parts.size < 2) return null
            val range = parts[0].split("-")
            if (range.size != 2) return null
            val start = range[0].toLongOrNull(16) ?: return null
            val end   = range[1].toLongOrNull(16) ?: return null
            val perms = parts[1]
            val pathname = parts.getOrNull(5)
            MapRegion(start, end, perms, pathname)
        } catch (_: Exception) { null }
    }

    private fun isSystemPath(path: String): Boolean {
        return SYSTEM_PATHS.any { path.contains(it) }
    }

    private fun readAndScanRegion(
        pid: String,
        start: Long,
        end: Long,
        size: Int,
        log: MutableList<String>
    ): List<ByteArray> {
        val results = mutableListOf<ByteArray>()

        // Use dd to read from /proc/<pid>/mem via root
        // Read in chunks to avoid OOM
        val totalChunks = (size + CHUNK_SIZE - 1) / CHUNK_SIZE
        val allBytes = mutableListOf<Byte>()

        for (chunk in 0 until totalChunks) {
            val offset = chunk.toLong() * CHUNK_SIZE
            val chunkSize = minOf(CHUNK_SIZE, size - (chunk * CHUNK_SIZE))
            if (chunkSize <= 0) break

            val skipBytes = start + offset
            val tmpFile = "/data/local/tmp/_mem_${pid}_${chunk}_${System.currentTimeMillis()}"

            // Read using dd from /proc/<pid>/mem
            val ddCmd = "dd if=/proc/$pid/mem bs=1 skip=$skipBytes count=$chunkSize " +
                        "of=$tmpFile 2>/dev/null && chmod 777 $tmpFile 2>/dev/null"
            RootShell.exec(ddCmd)

            val f = File(tmpFile)
            if (f.exists() && f.length() > 0) {
                try {
                    allBytes.addAll(f.readBytes().toList())
                } catch (_: Exception) {}
                f.delete()
            }
        }

        if (allBytes.isEmpty()) return results

        val bytes = allBytes.toByteArray()
        // Scan the buffer for DEX magic
        var offset = 0
        while (offset < bytes.size - 8) {
            if (matchesMagic(bytes, offset)) {
                val declaredSize = try {
                    ByteBuffer.wrap(bytes, offset + 32, 4)
                        .order(ByteOrder.LITTLE_ENDIAN).int
                } catch (_: Exception) { 0 }

                val takeSize = when {
                    declaredSize in MIN_DEX_SIZE..(bytes.size - offset) -> declaredSize
                    declaredSize > MIN_DEX_SIZE -> bytes.size - offset
                    else -> bytes.size - offset
                }

                if (takeSize >= MIN_DEX_SIZE) {
                    val dex = bytes.copyOfRange(offset,
                        minOf(offset + takeSize, bytes.size))
                    if (DexVerifier.isValid(dex)) {
                        results.add(dex)
                    }
                }
                offset += maxOf(takeSize, 1)
            } else {
                offset++
            }
        }

        return results
    }

    private fun matchesMagic(bytes: ByteArray, offset: Int): Boolean {
        if (offset + DEX_MAGIC.size > bytes.size) return false
        for (i in DEX_MAGIC.indices) {
            if (bytes[offset + i] != DEX_MAGIC[i]) return false
        }
        return true
    }
}
