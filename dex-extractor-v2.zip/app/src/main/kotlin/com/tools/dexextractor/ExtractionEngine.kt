package com.tools.dexextractor

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class ExtractionEngine(private val context: Context) {

    data class ExtractionResult(
        val success: Boolean,
        val outputDir: File?,
        val dexCount: Int,
        val reportPath: String?,
        val log: List<String>
    )

    suspend fun extract(packageName: String): ExtractionResult =
        withContext(Dispatchers.IO) {
            val log = mutableListOf<String>()
            val allDex = mutableListOf<ByteArray>()
            val seenHashes = mutableSetOf<String>()
            val strategiesUsed = mutableListOf<String>()

            log.add("═══════════════════════════════")
            log.add("  DEX Extractor — Starting")
            log.add("  Package: $packageName")
            log.add("═══════════════════════════════")

            // Init root shell
            RootShell.init()
            if (!RootShell.isAvailable()) {
                log.add("⚠ Root not available — some strategies will be skipped")
            } else {
                log.add("✓ Root access confirmed")
            }

            // Install compat layer
            CompatLayer.install(context)

            // Find APK path
            val apkPath = findApkPath(packageName, log)

            // ── Strategy A: ClassLoader Reflection ──────────────
            log.add("")
            log.add("--- Strategy A: ClassLoader Reflection ---")
            if (apkPath != null) {
                val resultA = StrategyA(context).extract(apkPath)
                log.addAll(resultA.log)
                resultA.dexList.forEach { bytes ->
                    val hash = DexVerifier.sha256(bytes)
                    if (seenHashes.add(hash)) allDex.add(bytes)
                }
                if (resultA.dexList.isNotEmpty()) strategiesUsed.add("A-reflection")
            } else {
                log.add("[A] Skipped — APK path not found")
            }

            // ── Strategy B: Memory Scan ──────────────────────────
            log.add("")
            log.add("--- Strategy B: Memory Scan ---")
            // Trigger load first if we have an APK path
            if (apkPath != null && allDex.isEmpty()) {
                log.add("[B] Triggering APK load before scan...")
                CompatLayer.safeLoad {
                    dalvik.system.DexClassLoader(
                        apkPath,
                        context.cacheDir.absolutePath,
                        null,
                        context.classLoader
                    )
                }
                Thread.sleep(500) // Give runtime time to map DEX
            }
            val resultB = StrategyB().scan()
            log.addAll(resultB.log)
            resultB.dexList.forEach { bytes ->
                val hash = DexVerifier.sha256(bytes)
                if (seenHashes.add(hash)) allDex.add(bytes)
            }
            if (resultB.dexList.isNotEmpty()) strategiesUsed.add("B-memscan")

            // ── Strategy C: Filesystem Search ────────────────────
            log.add("")
            log.add("--- Strategy C: Filesystem Search ---")
            val resultC = StrategyC(context).search(packageName)
            log.addAll(resultC.log)
            resultC.dexList.forEach { bytes ->
                val hash = DexVerifier.sha256(bytes)
                if (seenHashes.add(hash)) allDex.add(bytes)
            }
            if (resultC.dexList.isNotEmpty()) strategiesUsed.add("C-filesystem")

            // Filter stub DEX files (< 50KB are likely stubs)
            val realDex = allDex.filter { it.size >= 50 * 1024 }
            val stubCount = allDex.size - realDex.size
            if (stubCount > 0) {
                log.add("")
                log.add("Filtered $stubCount stub DEX file(s) (< 50KB)")
            }

            // ── Save results ─────────────────────────────────────
            log.add("")
            log.add("═══════════════════════════════")
            log.add("Total unique DEX found: ${realDex.size}")

            if (realDex.isEmpty()) {
                log.add("⚠ No DEX files extracted")
                return@withContext ExtractionResult(
                    success = false,
                    outputDir = null,
                    dexCount = 0,
                    reportPath = null,
                    log = log
                )
            }

            // Create output directory
            val timestamp = System.currentTimeMillis() / 1000
            val outDir = File("/sdcard/dex_output/$packageName/$timestamp")
            outDir.mkdirs()

            // Save each DEX
            val savedFiles = mutableListOf<Pair<File, ByteArray>>()
            realDex.forEachIndexed { i, bytes ->
                val outFile = File(outDir, "dump_${i}_${bytes.size}.dex")
                outFile.writeBytes(bytes)
                savedFiles.add(Pair(outFile, bytes))
                log.add("✅ Saved: ${outFile.absolutePath}")
            }

            // Write report
            val reportFile = ReportWriter.write(
                outDir, packageName, savedFiles, strategiesUsed
            )
            log.add("📄 Report: ${reportFile.absolutePath}")
            log.add("═══════════════════════════════")

            ExtractionResult(
                success     = true,
                outputDir   = outDir,
                dexCount    = realDex.size,
                reportPath  = reportFile.absolutePath,
                log         = log
            )
        }

    private fun findApkPath(packageName: String, log: MutableList<String>): String? {
        // Method 1: PackageManager
        try {
            val pm = context.packageManager
            val info = pm.getApplicationInfo(packageName, 0)
            if (info.sourceDir != null) {
                log.add("APK path (PM): ${info.sourceDir}")
                return info.sourceDir
            }
        } catch (e: Exception) {
            log.add("PM lookup failed: ${e.message}")
        }

        // Method 2: root pm path
        if (RootShell.isAvailable()) {
            val output = RootShell.exec("pm path $packageName 2>/dev/null")
            if (output.contains("package:")) {
                val path = output.substringAfter("package:").trim()
                if (path.isNotEmpty()) {
                    log.add("APK path (root pm): $path")
                    return path
                }
            }
        }

        log.add("Could not locate APK for $packageName")
        return null
    }
}
