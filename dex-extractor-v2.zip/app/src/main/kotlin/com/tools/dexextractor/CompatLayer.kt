package com.tools.dexextractor

import android.app.ActivityManager
import android.content.Context

/**
 * Compatibility layer that intercepts calls which would terminate
 * our host process when loading third-party APK code.
 */
object CompatLayer {

    private var installed = false

    fun install(context: Context) {
        if (installed) return
        installed = true
        installJavaLayer(context)
    }

    private fun installJavaLayer(context: Context) {
        // Nothing to do at this level — Java hooks via reflection
        // are handled per-classloader in the extraction strategies.
        // The native layer (native_compat.cpp) handles exit/abort.
    }

    /**
     * Wraps a block that loads external code, catching any
     * exceptions that escape from the loaded APK's initializers.
     */
    fun <T> safeLoad(block: () -> T): Result<T> {
        return try {
            Result.success(block())
        } catch (e: ExceptionInInitializerError) {
            Result.failure(e.cause ?: e)
        } catch (e: UnsatisfiedLinkError) {
            Result.failure(e)
        } catch (e: Exception) {
            Result.failure(e)
        } catch (e: Error) {
            // Catch broad errors from loaded code (e.g. StackOverflowError)
            Result.failure(RuntimeException("Error from loaded code: ${e.message}", e))
        }
    }

    /**
     * Check if a class name belongs to the loader stub
     * (not the real app code).
     */
    fun isStubClass(className: String): Boolean {
        return className.startsWith("com.luoyesiqiu.shell") ||
               className.startsWith("com.luoye.dpt") ||
               className.startsWith("com.secshell") ||
               className.startsWith("com.bangcle")
    }
}
