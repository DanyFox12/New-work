package com.tools.dexextractor

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest

object DexVerifier {

    private val DEX_MAGIC = byteArrayOf(0x64, 0x65, 0x78, 0x0a) // "dex\n"
    private val VALID_VERSIONS = setOf("035", "036", "037", "038", "039")
    const val MIN_DEX_SIZE = 10 * 1024 // 10 KB

    data class DexInfo(
        val size: Int,
        val version: String,
        val sha256: String
    )

    fun isValid(bytes: ByteArray): Boolean {
        if (bytes.size < 112) return false
        // Check magic
        for (i in DEX_MAGIC.indices) {
            if (bytes[i] != DEX_MAGIC[i]) return false
        }
        // Check version
        val version = String(bytes.slice(4..6).toByteArray())
        if (version !in VALID_VERSIONS) return false
        // Check minimum size
        if (bytes.size < MIN_DEX_SIZE) return false
        // Check declared size matches actual
        val declaredSize = ByteBuffer.wrap(bytes, 32, 4)
            .order(ByteOrder.LITTLE_ENDIAN).int
        return declaredSize > 0 && declaredSize <= bytes.size + 1024
    }

    fun getInfo(bytes: ByteArray): DexInfo? {
        if (!isValid(bytes)) return null
        val version = String(bytes.slice(4..6).toByteArray())
        val declaredSize = ByteBuffer.wrap(bytes, 32, 4)
            .order(ByteOrder.LITTLE_ENDIAN).int
        val sha256 = sha256(bytes)
        return DexInfo(declaredSize, version, sha256)
    }

    fun readDeclaredSize(bytes: ByteArray, offset: Int = 0): Int {
        if (bytes.size < offset + 36) return 0
        return ByteBuffer.wrap(bytes, offset + 32, 4)
            .order(ByteOrder.LITTLE_ENDIAN).int
    }

    fun sha256(bytes: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256")
        return digest.digest(bytes).joinToString("") { "%02x".format(it) }
    }
}
