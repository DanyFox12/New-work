package com.tools.dexextractor

import android.content.Context
import dalvik.system.BaseDexClassLoader
import dalvik.system.DexClassLoader
import java.io.File

/**
 * Strategy A: Load the target APK via DexClassLoader in our process,
 * then walk BaseDexClassLoader.pathList.dexElements via reflection
 * to extract the loaded DEX bytes.
 */
class StrategyA(private val context: Context) {

    data class Result(
        val dexList: List<ByteArray>,
        val log: List<String>
    )

    fun extract(apkPath: String): Result {
        val log = mutableListOf<String>()
        val found = mutableListOf<ByteArray>()

        log.add("[A] Starting ClassLoader reflection strategy")
        log.add("[A] APK: $apkPath")

        val cacheDir = File(context.cacheDir, "dex_opt_${System.currentTimeMillis()}")
        cacheDir.mkdirs()

        val loader = CompatLayer.safeLoad {
            DexClassLoader(
                apkPath,
                cacheDir.absolutePath,
                null,
                context.classLoader
            )
        }

        if (loader.isFailure) {
            log.add("[A] DexClassLoader failed: ${loader.exceptionOrNull()?.message}")
            return Result(found, log)
        }

        val cl = loader.getOrNull()!!
        log.add("[A] DexClassLoader created successfully")

        // Reflect into BaseDexClassLoader.pathList
        val pathList = try {
            val field = BaseDexClassLoader::class.java
                .getDeclaredField("pathList")
                .also { it.isAccessible = true }
            field.get(cl)
        } catch (e: Exception) {
            log.add("[A] Could not access pathList: ${e.message}")
            return Result(found, log)
        }

        if (pathList == null) {
            log.add("[A] pathList is null")
            return Result(found, log)
        }

        // Reflect into DexPathList.dexElements
        val elements = try {
            val dplClass = Class.forName("dalvik.system.DexPathList")
            val field = dplClass.getDeclaredField("dexElements")
                .also { it.isAccessible = true }
            field.get(pathList) as? Array<*>
        } catch (e: Exception) {
            log.add("[A] Could not access dexElements: ${e.message}")
            return Result(found, log)
        }

        if (elements == null) {
            log.add("[A] dexElements is null")
            return Result(found, log)
        }

        log.add("[A] Found ${elements.size} dexElements")

        elements.forEachIndexed { index, element ->
            element ?: return@forEachIndexed
            try {
                // Get dexFile field from element
                val dexFile = element.javaClass
                    .getDeclaredField("dexFile")
                    .also { it.isAccessible = true }
                    .get(element) ?: return@forEachIndexed

                // Try getName() to get file path
                val nameFn = dexFile.javaClass
                    .getDeclaredMethod("getName")
                    .also { it.isAccessible = true }
                val path = nameFn.invoke(dexFile)?.toString()

                log.add("[A] Element[$index] dexFile path: $path")

                if (path != null) {
                    val bytes = readDexFromPath(path, log)
                    if (bytes != null && DexVerifier.isValid(bytes)) {
                        found.add(bytes)
                        log.add("[A] Element[$index] → valid DEX ${bytes.size} bytes")
                    }
                }
            } catch (e: Exception) {
                log.add("[A] Element[$index] error: ${e.message}")
            }
        }

        cacheDir.deleteRecursively()
        log.add("[A] Done — found ${found.size} DEX file(s)")
        return Result(found, log)
    }

    private fun readDexFromPath(path: String, log: MutableList<String>): ByteArray? {
        // Try direct file read first
        val file = File(path)
        if (file.exists() && file.canRead()) {
            return try {
                file.readBytes()
            } catch (e: Exception) {
                log.add("[A] Direct read failed, trying root: ${e.message}")
                RootShell.readBytes(path)
            }
        }
        // Try root read
        return RootShell.readBytes(path)
    }
}
