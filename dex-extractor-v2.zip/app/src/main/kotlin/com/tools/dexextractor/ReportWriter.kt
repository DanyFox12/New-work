package com.tools.dexextractor

import com.google.gson.GsonBuilder
import java.io.File

object ReportWriter {

    data class DexEntry(
        val index: Int,
        val path: String,
        val size_bytes: Int,
        val sha256: String,
        val dex_version: String
    )

    data class Report(
        val package_name: String,
        val timestamp: Long,
        val loader_type: String,
        val strategies_used: List<String>,
        val total_dex_found: Int,
        val dex_files: List<DexEntry>
    )

    fun write(
        outputDir: File,
        packageName: String,
        dexFiles: List<Pair<File, ByteArray>>,
        strategiesUsed: List<String>
    ): File {
        val loaderType = detectLoaderType(packageName)
        val entries = dexFiles.mapIndexed { i, (file, bytes) ->
            val info = DexVerifier.getInfo(bytes)
            DexEntry(
                index       = i,
                path        = file.absolutePath,
                size_bytes  = bytes.size,
                sha256      = info?.sha256 ?: DexVerifier.sha256(bytes),
                dex_version = info?.version ?: "unknown"
            )
        }

        val report = Report(
            package_name    = packageName,
            timestamp       = System.currentTimeMillis() / 1000,
            loader_type     = loaderType,
            strategies_used = strategiesUsed,
            total_dex_found = dexFiles.size,
            dex_files       = entries
        )

        val gson = GsonBuilder().setPrettyPrinting().create()
        val json = gson.toJson(report)
        val reportFile = File(outputDir, "report.json")
        reportFile.writeText(json)
        return reportFile
    }

    private fun detectLoaderType(packageName: String): String {
        // Could be extended to inspect the APK
        return "dpt-shell"
    }
}
