package com.tools.dexextractor

import android.content.Context
import java.io.File
import java.util.zip.ZipFile

/**
 * Strategy C: Use root access to search the filesystem for
 * DEX files — both extracted temp files and encoded asset containers.
 */
class StrategyC(private val context: Context) {

    data class Result(
        val dexList: List<ByteArray>,
        val log: List<String>
    )

    fun search(packageName: String): Result {
        val log = mutableListOf<String>()
        val found = mutableListOf<ByteArray>()
        val seenHashes = mutableSetOf<String>()

        log.add("[C] Starting filesystem search for: $packageName")

        if (!RootShell.isAvailable()) {
            log.add("[C] Root not available — skipping")
            return Result(found, log)
        }

        // Paths to check
        val searchPaths = listOf(
            "/data/data/$packageName",
            "/data/data/$packageName/app_dex",
            "/data/data/$packageName/files",
            "/data/data/$packageName/cache",
            "/data/data/$packageName/code_cache",
            "/data/app/$packageName",
            "/data/user/0/$packageName",
            "/data/user/0/$packageName/app_dex",
            "/data/user/0/$packageName/files",
        )

        // Also find the actual APK path
        val apkPath = findApkPath(packageName, log)
        if (apkPath != null) {
            log.add("[C] APK found at: $apkPath")
            extractDexFromApk(apkPath, log, found, seenHashes)
        }

        // Search all paths
        searchPaths.forEach { path ->
            if (RootShell.exists(path)) {
                log.add("[C] Searching: $path")
                findDexFilesIn(path, log, found, seenHashes)
            }
        }

        log.add("[C] Done — found ${found.size} DEX file(s)")
        return Result(found, log)
    }

    private fun findApkPath(packageName: String, log: MutableList<String>): String? {
        // Try pm path command
        val pmOutput = RootShell.exec("pm path $packageName 2>/dev/null")
        if (pmOutput.contains("package:")) {
            val path = pmOutput.substringAfter("package:").trim()
            if (path.isNotEmpty()) return path
        }
        // Fallback: find in /data/app
        val findOutput = RootShell.exec(
            "find /data/app -name 'base.apk' -path '*$packageName*' 2>/dev/null | head -1"
        )
        return findOutput.trim().takeIf { it.isNotEmpty() }
    }

    private fun extractDexFromApk(
        apkPath: String,
        log: MutableList<String>,
        found: MutableList<ByteArray>,
        seenHashes: MutableSet<String>
    ) {
        // Copy APK to a readable location
        val tmpApk = File(context.cacheDir, "tmp_${System.currentTimeMillis()}.apk")
        try {
            if (!RootShell.copy(apkPath, tmpApk.absolutePath)) {
                log.add("[C] Could not copy APK to cache")
                return
            }
            tmpApk.setReadable(true, false)

            ZipFile(tmpApk).use { zip ->
                val entries = zip.entries().toList()
                log.add("[C] APK has ${entries.size} entries")

                entries.forEach { entry ->
                    val name = entry.name
                    // Standard DEX files
                    if (name.matches(Regex("classes\\d*\\.dex"))) {
                        val bytes = zip.getInputStream(entry).readBytes()
                        if (DexVerifier.isValid(bytes)) {
                            val hash = DexVerifier.sha256(bytes)
                            if (seenHashes.add(hash)) {
                                found.add(bytes)
                                log.add("[C] APK entry: $name (${bytes.size} bytes)")
                            }
                        }
                    }
                    // Packed assets — try to read and check for DEX magic
                    if (name.startsWith("assets/") && !name.endsWith("/")) {
                        try {
                            val bytes = zip.getInputStream(entry).readBytes()
                            if (bytes.size >= DexVerifier.MIN_DEX_SIZE &&
                                DexVerifier.isValid(bytes)) {
                                val hash = DexVerifier.sha256(bytes)
                                if (seenHashes.add(hash)) {
                                    found.add(bytes)
                                    log.add("[C] Asset DEX: $name (${bytes.size} bytes)")
                                }
                            }
                        } catch (_: Exception) {}
                    }
                }
            }
        } catch (e: Exception) {
            log.add("[C] APK extraction error: ${e.message}")
        } finally {
            tmpApk.delete()
        }
    }

    private fun findDexFilesIn(
        dirPath: String,
        log: MutableList<String>,
        found: MutableList<ByteArray>,
        seenHashes: MutableSet<String>
    ) {
        val files = RootShell.exec(
            "find '$dirPath' -name '*.dex' -o -name '*.vdex' 2>/dev/null"
        ).lines().filter { it.isNotBlank() }

        log.add("[C] $dirPath → ${files.size} .dex file(s)")

        files.forEach { filePath ->
            val bytes = RootShell.readBytes(filePath) ?: return@forEach
            if (DexVerifier.isValid(bytes)) {
                val hash = DexVerifier.sha256(bytes)
                if (seenHashes.add(hash)) {
                    found.add(bytes)
                    log.add("[C] Found: $filePath (${bytes.size} bytes)")
                }
            }
        }
    }
}
