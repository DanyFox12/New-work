package com.tools.dexextractor

import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

data class AppInfo(
    val appName: String,
    val packageName: String,
    val icon: Drawable?,
    val isSystemApp: Boolean
)

class AppAdapter(
    private var apps: List<AppInfo>,
    private val onSelect: (AppInfo) -> Unit
) : RecyclerView.Adapter<AppAdapter.ViewHolder>() {

    private var selectedPkg: String? = null
    private var filtered: List<AppInfo> = apps

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView   = view.findViewById(R.id.iv_app_icon)
        val name: TextView    = view.findViewById(R.id.tv_app_name)
        val pkg: TextView     = view.findViewById(R.id.tv_pkg_name)
        val check: TextView   = view.findViewById(R.id.tv_selected_check)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_app, parent, false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val app = filtered[position]
        holder.name.text = app.appName
        holder.pkg.text  = app.packageName
        holder.icon.setImageDrawable(app.icon)
        holder.check.visibility =
            if (app.packageName == selectedPkg) View.VISIBLE else View.GONE

        holder.itemView.setOnClickListener {
            val prev = selectedPkg
            selectedPkg = app.packageName
            // Refresh changed items
            filtered.indexOfFirst { it.packageName == prev }
                .takeIf { it >= 0 }?.let { notifyItemChanged(it) }
            notifyItemChanged(position)
            onSelect(app)
        }
    }

    override fun getItemCount() = filtered.size

    fun filter(query: String) {
        filtered = if (query.isBlank()) apps
        else apps.filter {
            it.appName.contains(query, ignoreCase = true) ||
            it.packageName.contains(query, ignoreCase = true)
        }
        notifyDataSetChanged()
    }

    fun setSelected(pkg: String) {
        selectedPkg = pkg
        notifyDataSetChanged()
    }

    companion object {
        fun loadInstalledApps(pm: PackageManager): List<AppInfo> {
            return pm.getInstalledApplications(PackageManager.GET_META_DATA)
                .filter { info ->
                    // Only show user-installed apps
                    (info.flags and ApplicationInfo.FLAG_SYSTEM) == 0 ||
                    (info.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
                }
                .map { info ->
                    AppInfo(
                        appName     = pm.getApplicationLabel(info).toString(),
                        packageName = info.packageName,
                        icon        = try { pm.getApplicationIcon(info.packageName) }
                                      catch (_: Exception) { null },
                        isSystemApp = (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                    )
                }
                .sortedBy { it.appName.lowercase() }
        }
    }
}
