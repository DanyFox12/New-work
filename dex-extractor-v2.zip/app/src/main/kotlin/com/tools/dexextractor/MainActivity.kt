package com.tools.dexextractor

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var etSearch: EditText
    private lateinit var rvApps: RecyclerView
    private lateinit var llSelected: LinearLayout
    private lateinit var ivSelectedIcon: ImageView
    private lateinit var tvSelectedName: TextView
    private lateinit var tvSelectedPkg: TextView
    private lateinit var btnExtract: Button
    private lateinit var tvStatus: TextView
    private lateinit var tvLog: TextView
    private lateinit var scrollLog: ScrollView
    private lateinit var tvRootBadge: TextView
    private lateinit var tvClear: TextView

    private lateinit var adapter: AppAdapter
    private var selectedApp: AppInfo? = null
    private val engine by lazy { ExtractionEngine(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bindViews()
        setupRecyclerView()
        setupListeners()
        checkRootAndPermissions()
    }

    private fun bindViews() {
        etSearch       = findViewById(R.id.et_search)
        rvApps         = findViewById(R.id.rv_apps)
        llSelected     = findViewById(R.id.ll_selected)
        ivSelectedIcon = findViewById(R.id.iv_selected_icon)
        tvSelectedName = findViewById(R.id.tv_selected_name)
        tvSelectedPkg  = findViewById(R.id.tv_selected_pkg)
        btnExtract     = findViewById(R.id.btn_extract)
        tvStatus       = findViewById(R.id.tv_status)
        tvLog          = findViewById(R.id.tv_log)
        scrollLog      = findViewById(R.id.scroll_log)
        tvRootBadge    = findViewById(R.id.tv_root_badge)
        tvClear        = findViewById(R.id.tv_clear)
    }

    private fun setupRecyclerView() {
        appendLog("Loading installed apps…")
        lifecycleScope.launch {
            val apps = withContext(Dispatchers.IO) {
                AppAdapter.loadInstalledApps(packageManager)
            }
            adapter = AppAdapter(apps) { app -> onAppSelected(app) }
            rvApps.layoutManager = LinearLayoutManager(this@MainActivity)
            rvApps.adapter = adapter
            appendLog("Found ${apps.size} user apps")
        }
    }

    private fun setupListeners() {
        // Search filter
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                adapter.filter(s?.toString() ?: "")
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        // Extract button
        btnExtract.setOnClickListener {
            val app = selectedApp
            if (app == null) {
                setStatus("⚠ Select an app first", "#FFD740")
                return@setOnClickListener
            }
            startExtraction(app)
        }

        // Clear log
        tvClear.setOnClickListener {
            tvLog.text = ""
        }
    }

    private fun onAppSelected(app: AppInfo) {
        selectedApp = app
        llSelected.visibility   = View.VISIBLE
        ivSelectedIcon.setImageDrawable(app.icon)
        tvSelectedName.text = app.appName
        tvSelectedPkg.text  = app.packageName
        setStatus("Ready — ${app.appName}", "#B388FF")
        appendLog("Selected: ${app.packageName}")
    }

    private fun startExtraction(app: AppInfo) {
        btnExtract.isEnabled = false
        tvLog.text = ""
        setStatus("⚡ Extracting ${app.appName}…", "#7C4DFF")

        lifecycleScope.launch {
            val result = engine.extract(app.packageName)

            tvLog.text = result.log.joinToString("\n")
            scrollLog.post { scrollLog.fullScroll(View.FOCUS_DOWN) }

            if (result.success) {
                setStatus(
                    "✅ Done — ${result.dexCount} DEX saved to /sdcard/dex_output/",
                    "#00E676"
                )
            } else {
                setStatus("⚠ No DEX files found", "#FF5252")
            }

            btnExtract.isEnabled = true
        }
    }

    private fun appendLog(msg: String) {
        runOnUiThread {
            tvLog.append("> $msg\n")
            scrollLog.post { scrollLog.fullScroll(View.FOCUS_DOWN) }
        }
    }

    private fun setStatus(msg: String, colorHex: String) {
        runOnUiThread {
            tvStatus.text = msg
            tvStatus.setTextColor(android.graphics.Color.parseColor(colorHex))
        }
    }

    private fun checkRootAndPermissions() {
        lifecycleScope.launch(Dispatchers.IO) {
            RootShell.init()
            val hasRoot = RootShell.isAvailable()
            withContext(Dispatchers.Main) {
                if (hasRoot) {
                    tvRootBadge.text = "  ROOT  "
                    tvRootBadge.setBackgroundResource(R.drawable.badge_bg)
                    appendLog("✓ Root access granted")
                } else {
                    tvRootBadge.text = "  NO ROOT  "
                    tvRootBadge.setTextColor(
                        ContextCompat.getColor(this@MainActivity, android.R.color.white))
                    appendLog("⚠ Root not available — limited functionality")
                }
            }
        }
        requestStoragePermission()
    }

    private fun requestStoragePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                try {
                    val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                    intent.data = Uri.parse("package:$packageName")
                    startActivity(intent)
                } catch (_: Exception) {
                    val intent = Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                    startActivity(intent)
                }
            }
        } else {
            val perms = arrayOf(
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            )
            val needed = perms.filter {
                ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
            }
            if (needed.isNotEmpty()) {
                ActivityCompat.requestPermissions(this, needed.toTypedArray(), 1)
            }
        }
    }
}
