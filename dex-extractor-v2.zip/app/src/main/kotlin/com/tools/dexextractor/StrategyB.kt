package com.tools.dexextractor

import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Strategy B: Parse /proc/self/maps to find memory regions,
 * then scan each readable non-system region for DEX magic bytes.
 */
class StrategyB {

    data class Result(
        val dexList: List<ByteArray>,
        val log: List<String>
    )

    private val DEX_MAGIC = byteArrayOf(0x64, 0x65, 0x78, 0x0a)

    private val SYSTEM_PATHS = listOf(
        "/system/", "/apex/", "/vendor/", "/product/",
        "/data/dalvik-cache", "/dev/", "[vdso]", "[stack]",
        "[heap]", "libc.so", "libdvm", "libandroid_runtime"
    )

    fun scan(): Result {
        val log = mutableListOf<String>()
        val found = mutableListOf<ByteArray>()
        val seenHashes = mutableSetOf<String>()

        log.add("[B] Starting memory scan strategy")

        val maps = try {
            File("/proc/self/maps").readLines()
        } catch (e: Exception) {
            log.add("[B] Cannot read /proc/self/maps: ${e.message}")
            return Result(found, log)
        }

        log.add("[B] Found ${maps.size} memory regions")

        var scanned = 0
        var skipped = 0

        maps.forEach { line ->
            val region = parseMapLine(line) ?: return@forEach

            // Only readable regions
            if (!region.perms.contains('r')) {
                skipped++
                return@forEach
            }

            // Skip tiny regions
            val size = region.end - region.start
            if (size < DexVerifier.MIN_DEX_SIZE) {
                skipped++
                return@forEach
            }

            // Skip system paths
            if (region.pathname != null && isSystemPath(region.pathname)) {
                skipped++
                return@forEach
            }

            scanned++
            val dexBytes = extractDexFromRegion(region.start, size.toInt(), log)
            dexBytes.forEach { bytes ->
                if (DexVerifier.isValid(bytes)) {
                    val hash = DexVerifier.sha256(bytes)
                    if (seenHashes.add(hash)) {
                        found.add(bytes)
                        log.add("[B] Found DEX @ 0x${region.start.toString(16)} size=${bytes.size}")
                    }
                }
            }
        }

        log.add("[B] Scanned=$scanned skipped=$skipped found=${found.size}")
        return Result(found, log)
    }

    private data class MapRegion(
        val start: Long,
        val end: Long,
        val perms: String,
        val pathname: String?
    )

    private fun parseMapLine(line: String): MapRegion? {
        return try {
            val parts = line.trim().split("\\s+".toRegex())
            if (parts.size < 2) return null
            val range = parts[0].split("-")
            if (range.size != 2) return null
            val start = range[0].toLongOrNull(16) ?: return null
            val end   = range[1].toLongOrNull(16) ?: return null
            val perms = parts[1]
            val pathname = parts.getOrNull(5)
            MapRegion(start, end, perms, pathname)
        } catch (e: Exception) {
            null
        }
    }

    private fun isSystemPath(path: String): Boolean {
        return SYSTEM_PATHS.any { path.contains(it) }
    }

    private fun extractDexFromRegion(
        start: Long,
        size: Int,
        log: MutableList<String>
    ): List<ByteArray> {
        val results = mutableListOf<ByteArray>()

        val bytes = try {
            readMemoryRegion(start, size) ?: return results
        } catch (e: Exception) {
            return results
        }

        // Scan bytes for DEX magic
        var offset = 0
        while (offset < bytes.size - 8) {
            if (matchesMagic(bytes, offset)) {
                val declaredSize = try {
                    ByteBuffer.wrap(bytes, offset + 32, 4)
                        .order(ByteOrder.LITTLE_ENDIAN).int
                } catch (e: Exception) {
                    0
                }

                val takeSize = when {
                    declaredSize > DexVerifier.MIN_DEX_SIZE &&
                    declaredSize <= (bytes.size - offset) -> declaredSize
                    declaredSize > DexVerifier.MIN_DEX_SIZE &&
                    declaredSize <= bytes.size -> bytes.size - offset
                    else -> bytes.size - offset
                }

                if (takeSize >= DexVerifier.MIN_DEX_SIZE) {
                    val dex = bytes.copyOfRange(offset,
                        minOf(offset + takeSize, bytes.size))
                    results.add(dex)
                }

                // Jump past this DEX
                offset += maxOf(takeSize, 1)
            } else {
                offset++
            }
        }

        return results
    }

    private fun readMemoryRegion(start: Long, size: Int): ByteArray? {
        return try {
            RandomAccessFile("/proc/self/mem", "r").use { mem ->
                mem.seek(start)
                val buf = ByteArray(size)
                val read = mem.read(buf)
                if (read > 0) buf.copyOf(read) else null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun matchesMagic(bytes: ByteArray, offset: Int): Boolean {
        if (offset + DEX_MAGIC.size > bytes.size) return false
        for (i in DEX_MAGIC.indices) {
            if (bytes[offset + i] != DEX_MAGIC[i]) return false
        }
        return true
    }
}
