package com.tools.dexextractor

import com.topjohnwu.superuser.Shell

object RootShell {

    fun init() {
        Shell.enableVerboseLogging = false
        Shell.setDefaultBuilder(
            Shell.Builder.create()
                .setFlags(Shell.FLAG_REDIRECT_STDERR)
                .setTimeout(10)
        )
    }

    fun isAvailable(): Boolean {
        return try {
            Shell.getShell().isRoot
        } catch (e: Exception) {
            false
        }
    }

    fun exec(cmd: String): String {
        return try {
            Shell.cmd(cmd).exec().out.joinToString("\n")
        } catch (e: Exception) {
            ""
        }
    }

    fun execLines(cmd: String): List<String> {
        return try {
            Shell.cmd(cmd).exec().out.filter { it.isNotBlank() }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun copy(src: String, dst: String): Boolean {
        return try {
            val result = Shell.cmd("cp -f '$src' '$dst'").exec()
            result.isSuccess
        } catch (e: Exception) {
            false
        }
    }

    fun listDir(path: String): List<String> {
        return execLines("ls '$path' 2>/dev/null")
    }

    fun exists(path: String): Boolean {
        return exec("[ -e '$path' ] && echo yes || echo no").trim() == "yes"
    }

    fun mkdir(path: String) {
        exec("mkdir -p '$path'")
    }

    fun readBytes(path: String): ByteArray? {
        return try {
            val tmpPath = "/data/local/tmp/_dex_read_${System.currentTimeMillis()}"
            exec("cp '$path' '$tmpPath' && chmod 777 '$tmpPath'")
            val file = java.io.File(tmpPath)
            if (file.exists()) {
                val bytes = file.readBytes()
                file.delete()
                bytes
            } else null
        } catch (e: Exception) {
            null
        }
    }
}
