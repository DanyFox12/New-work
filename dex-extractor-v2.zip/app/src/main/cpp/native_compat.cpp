#include <jni.h>
#include <android/log.h>
#include <dlfcn.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>

#define TAG "DexExtractor"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,  TAG, __VA_ARGS__)

// ── Intercept exit() to keep our process alive ───────────────────
// We override the weak symbol — this takes effect for code loaded
// after this library, including any JNI libs from the target APK.

extern "C" {

// Block exit() from loaded code
void exit(int status) {
    LOGW("exit(%d) intercepted — suppressed", status);
    // Don't call the real exit — just return
}

// Block _exit()
void _exit(int status) {
    LOGW("_exit(%d) intercepted — suppressed", status);
}

// Block abort()
void abort() {
    LOGW("abort() intercepted — suppressed");
}

// Block raise() for fatal signals
int raise(int sig) {
    if (sig == SIGKILL || sig == SIGABRT || sig == SIGTERM) {
        LOGW("raise(sig=%d) intercepted — suppressed", sig);
        return 0;
    }
    // Allow other signals through
    return kill(getpid(), sig);
}

// ── JNI interface ─────────────────────────────────────────────────

JNIEXPORT jstring JNICALL
Java_com_tools_dexextractor_CompatLayer_nativeVersion(
        JNIEnv* env, jobject /* this */) {
    return env->NewStringUTF("native_compat v1.0 loaded");
}

JNIEXPORT jboolean JNICALL
Java_com_tools_dexextractor_CompatLayer_isNativeLoaded(
        JNIEnv* env, jobject /* this */) {
    return JNI_TRUE;
}

} // extern "C"
